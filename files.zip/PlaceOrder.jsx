import React from "react";
import { CheckCircle2 } from "lucide-react";
import { COLORS, cardStyle, primaryButtonStyle } from "./tokens";

export default function PlaceOrder({ order, onContinueShopping }) {
  if (!order) return null;

  return (
    <div style={{ maxWidth: 460, margin: "60px auto", fontFamily: "'Inter', sans-serif" }}>
      <div style={{ ...cardStyle, textAlign: "center" }}>
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: "50%",
            background: COLORS.tealSoft,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 16px",
          }}
        >
          <CheckCircle2 size={26} color={COLORS.teal} />
        </div>
        <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 21, fontWeight: 600, margin: "0 0 6px" }}>
          Order placed
        </h1>
        <p style={{ fontSize: 13, color: COLORS.inkSoft, margin: "0 0 20px" }}>
          Order {order.id} is confirmed. A receipt has been sent to your email.
        </p>

        <div style={{ textAlign: "left", borderTop: `1px solid ${COLORS.border}`, paddingTop: 14 }}>
          {order.items.map(({ product, qty }) => (
            <div
              key={product.id}
              style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 8 }}
            >
              <span>
                {product.name} <span style={{ color: COLORS.inkSoft }}>&times;{qty}</span>
              </span>
              <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                ${(product.price * qty).toFixed(2)}
              </span>
            </div>
          ))}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              fontSize: 14,
              fontWeight: 600,
              borderTop: `1px solid ${COLORS.border}`,
              paddingTop: 10,
              marginTop: 6,
            }}
          >
            <span>Total</span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>${order.total.toFixed(2)}</span>
          </div>
        </div>

        <button onClick={onContinueShopping} style={{ ...primaryButtonStyle, marginTop: 20 }}>
          Continue shopping
        </button>
      </div>
    </div>
  );
}
