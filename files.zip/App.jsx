import React, { useState } from "react";
import { COLORS } from "./tokens";
import Register from "./Register";
import Login from "./Login";
import ProductList from "./ProductList";
import Cart from "./Cart";
import PlaceOrder from "./PlaceOrder";

// In-memory mock "database" for this module. Replace with real API calls
// (e.g. fetch to /api/register, /api/login, /api/orders) when wiring up a backend.
const SEED_USERS = [{ name: "Demo User", email: "demo@example.com", password: "password123" }];

export default function App() {
  const [users, setUsers] = useState(SEED_USERS);
  const [user, setUser] = useState(null);
  const [view, setView] = useState("login"); // login | register | products | cart | order
  const [cart, setCart] = useState([]); // [{ product, qty }]
  const [lastOrder, setLastOrder] = useState(null);

  function handleRegister(newUser) {
    setUsers((u) => [...u, newUser]);
    setUser(newUser);
    setView("products");
  }

  function handleLogin(loggedInUser) {
    setUser(loggedInUser);
    setView("products");
  }

  function handleAddToCart(product) {
    setCart((c) => {
      const existing = c.find((i) => i.product.id === product.id);
      if (existing) {
        return c.map((i) => (i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...c, { product, qty: 1 }];
    });
  }

  function handleUpdateQty(productId, qty) {
    setCart((c) => c.map((i) => (i.product.id === productId ? { ...i, qty } : i)));
  }

  function handleRemove(productId) {
    setCart((c) => c.filter((i) => i.product.id !== productId));
  }

  function handlePlaceOrder() {
    const total = cart.reduce((sum, i) => sum + i.product.price * i.qty, 0);
    const order = {
      id: "ORD-" + Math.floor(1000 + Math.random() * 9000),
      items: cart,
      total,
    };
    setLastOrder(order);
    setCart([]);
    setView("order");
  }

  return (
    <div style={{ minHeight: "100vh", background: COLORS.bg }}>
      {view === "register" && (
        <Register users={users} onRegister={handleRegister} goToLogin={() => setView("login")} />
      )}

      {view === "login" && (
        <Login users={users} onLogin={handleLogin} goToRegister={() => setView("register")} />
      )}

      {view === "products" && user && (
        <ProductList
          user={user}
          cartCount={cart.reduce((n, i) => n + i.qty, 0)}
          onAddToCart={handleAddToCart}
          onOpenCart={() => setView("cart")}
        />
      )}

      {view === "cart" && (
        <Cart
          items={cart}
          onUpdateQty={handleUpdateQty}
          onRemove={handleRemove}
          onBack={() => setView("products")}
          onPlaceOrder={handlePlaceOrder}
        />
      )}

      {view === "order" && (
        <PlaceOrder order={lastOrder} onContinueShopping={() => setView("products")} />
      )}
    </div>
  );
}
