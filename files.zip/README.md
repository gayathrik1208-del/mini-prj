# Module 1 — User Module

React components covering: register, login, view products, search products, add to cart, place order.

## Files

- `App.jsx` — top-level state and routing between views (register/login/products/cart/order)
- `Register.jsx` — new account form, checks for duplicate email
- `Login.jsx` — email/password login against the mock user list
- `ProductList.jsx` — browse + search + category filter + add to cart
- `Cart.jsx` — line items with quantity controls, subtotal, place order
- `PlaceOrder.jsx` — order confirmation screen with receipt summary
- `products.js` — sample product catalog
- `tokens.js` — shared colors/styles used across all screens

## Data layer

Everything runs on in-memory React state (`SEED_USERS` in `App.jsx`, `PRODUCTS` in `products.js`) —
no backend required to preview it. To connect a real backend:

- Replace `handleRegister` / `handleLogin` in `App.jsx` with calls to your auth API
- Replace `PRODUCTS` with a fetch to your product listing endpoint
- Replace `handlePlaceOrder` with a call to your orders API, using the returned order id

## Running it

Drop this folder into a React project (Vite or Create React App). Dependencies used:
`lucide-react` for icons. Import `App` from `./App` and render it as your root component.

```bash
npm install lucide-react
```

## Demo login

A seed account is included so you can log in immediately without registering first:

- Email: `demo@example.com`
- Password: `password123`
