import React, { useMemo, useState } from "react";
import { Search, ShoppingCart, Plus } from "lucide-react";
import { COLORS, cardStyle, inputStyle } from "./tokens";
import { PRODUCTS } from "./products";

export default function ProductList({ user, cartCount, onAddToCart, onOpenCart }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");

  const categories = useMemo(() => ["all", ...new Set(PRODUCTS.map((p) => p.category))], []);

  const filtered = useMemo(() => {
    return PRODUCTS.filter((p) => {
      const matchesQuery = p.name.toLowerCase().includes(query.toLowerCase());
      const matchesCategory = category === "all" || p.category === category;
      return matchesQuery && matchesCategory;
    });
  }, [query, category]);

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 24px", fontFamily: "'Inter', sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 24, fontWeight: 600, margin: 0 }}>
            Welcome, {user.name.split(" ")[0]}
          </h1>
          <p style={{ fontSize: 13, color: COLORS.inkSoft, marginTop: 4 }}>Browse and search products.</p>
        </div>
        <button
          onClick={onOpenCart}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            border: `1px solid ${COLORS.border}`,
            background: "#fff",
            borderRadius: 8,
            padding: "9px 14px",
            fontSize: 13.5,
            fontWeight: 600,
            cursor: "pointer",
            color: COLORS.ink,
          }}
        >
          <ShoppingCart size={16} />
          Cart {cartCount > 0 && `(${cartCount})`}
        </button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            border: `1px solid ${COLORS.border}`,
            borderRadius: 8,
            padding: "9px 12px",
            background: "#fff",
            flex: 1,
            maxWidth: 320,
          }}
        >
          <Search size={15} color={COLORS.inkSoft} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products"
            style={{ border: "none", outline: "none", background: "transparent", fontSize: 13.5, width: "100%" }}
          />
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              style={{
                border: `1px solid ${category === c ? COLORS.ink : COLORS.border}`,
                background: category === c ? COLORS.ink : "#fff",
                color: category === c ? "#fff" : COLORS.inkSoft,
                borderRadius: 8,
                padding: "8px 12px",
                fontSize: 13,
                fontWeight: 500,
                cursor: "pointer",
                textTransform: "capitalize",
              }}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 14 }}>
        {filtered.map((p) => (
          <div key={p.id} style={{ ...cardStyle, padding: 16, display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontSize: 11.5, color: COLORS.inkSoft, textTransform: "uppercase", letterSpacing: 0.4 }}>
              {p.category}
            </div>
            <div style={{ fontSize: 14.5, fontWeight: 600 }}>{p.name}</div>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 15, color: COLORS.teal }}>
              ${p.price}
            </div>
            <div style={{ fontSize: 12, color: COLORS.inkSoft }}>{p.stock} in stock</div>
            <button
              onClick={() => onAddToCart(p)}
              style={{
                marginTop: 6,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 6,
                border: "none",
                borderRadius: 8,
                padding: "8px 10px",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                background: COLORS.tealSoft,
                color: COLORS.teal,
              }}
            >
              <Plus size={14} />
              Add to cart
            </button>
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{ gridColumn: "1 / -1", textAlign: "center", color: COLORS.inkSoft, fontSize: 13.5, padding: 32 }}>
            No products match your search.
          </div>
        )}
      </div>
    </div>
  );
}
