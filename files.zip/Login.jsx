import React, { useState } from "react";
import { COLORS, inputStyle, primaryButtonStyle, cardStyle } from "./tokens";

export default function Login({ users, onLogin, goToRegister }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || user.password !== password) {
      setError("That email or password isn't right.");
      return;
    }
    onLogin(user);
  }

  return (
    <div style={{ maxWidth: 380, margin: "60px auto", fontFamily: "'Inter', sans-serif" }}>
      <div style={cardStyle}>
        <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>
          Welcome back
        </h1>
        <p style={{ fontSize: 13, color: COLORS.inkSoft, margin: "0 0 20px" }}>
          Log in to continue shopping.
        </p>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label style={{ fontSize: 12.5, color: COLORS.inkSoft, display: "block", marginBottom: 6 }}>
              Email
            </label>
            <input
              style={inputStyle}
              type="email"
              placeholder="name@company.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError("");
              }}
            />
          </div>
          <div>
            <label style={{ fontSize: 12.5, color: COLORS.inkSoft, display: "block", marginBottom: 6 }}>
              Password
            </label>
            <input
              style={inputStyle}
              type="password"
              placeholder="Your password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
            />
          </div>

          {error && <div style={{ fontSize: 13, color: COLORS.rose }}>{error}</div>}

          <button type="submit" style={primaryButtonStyle}>
            Log in
          </button>
        </form>

        <p style={{ fontSize: 13, color: COLORS.inkSoft, marginTop: 18, textAlign: "center" }}>
          New here?{" "}
          <button
            onClick={goToRegister}
            style={{ border: "none", background: "none", color: COLORS.teal, fontWeight: 600, cursor: "pointer", padding: 0 }}
          >
            Create an account
          </button>
        </p>
      </div>
    </div>
  );
}
