import React, { useState } from "react";
import { COLORS, inputStyle, primaryButtonStyle, cardStyle } from "./tokens";

// Simulates a users table. In a real app this lives in a database.
export default function Register({ users, onRegister, goToLogin }) {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  function handleChange(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    setError("");
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.password.trim()) {
      setError("Fill in every field to continue.");
      return;
    }
    if (users.some((u) => u.email.toLowerCase() === form.email.toLowerCase())) {
      setError("An account with that email already exists.");
      return;
    }
    onRegister({ name: form.name, email: form.email, password: form.password });
  }

  return (
    <div style={{ maxWidth: 380, margin: "60px auto", fontFamily: "'Inter', sans-serif" }}>
      <div style={cardStyle}>
        <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 600, margin: "0 0 4px" }}>
          Create your account
        </h1>
        <p style={{ fontSize: 13, color: COLORS.inkSoft, margin: "0 0 20px" }}>
          Register to start browsing and ordering.
        </p>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label style={{ fontSize: 12.5, color: COLORS.inkSoft, display: "block", marginBottom: 6 }}>
              Full name
            </label>
            <input
              style={inputStyle}
              placeholder="Aiko Sato"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
            />
          </div>
          <div>
            <label style={{ fontSize: 12.5, color: COLORS.inkSoft, display: "block", marginBottom: 6 }}>
              Email
            </label>
            <input
              style={inputStyle}
              type="email"
              placeholder="name@company.com"
              value={form.email}
              onChange={(e) => handleChange("email", e.target.value)}
            />
          </div>
          <div>
            <label style={{ fontSize: 12.5, color: COLORS.inkSoft, display: "block", marginBottom: 6 }}>
              Password
            </label>
            <input
              style={inputStyle}
              type="password"
              placeholder="At least 8 characters"
              value={form.password}
              onChange={(e) => handleChange("password", e.target.value)}
            />
          </div>

          {error && <div style={{ fontSize: 13, color: COLORS.rose }}>{error}</div>}

          <button type="submit" style={primaryButtonStyle}>
            Create account
          </button>
        </form>

        <p style={{ fontSize: 13, color: COLORS.inkSoft, marginTop: 18, textAlign: "center" }}>
          Already have an account?{" "}
          <button
            onClick={goToLogin}
            style={{ border: "none", background: "none", color: COLORS.teal, fontWeight: 600, cursor: "pointer", padding: 0 }}
          >
            Log in
          </button>
        </p>
      </div>
    </div>
  );
}
