import React from "react";
import { Minus, Plus, Trash2, ArrowLeft } from "lucide-react";
import { COLORS, cardStyle, primaryButtonStyle } from "./tokens";

export default function Cart({ items, onUpdateQty, onRemove, onBack, onPlaceOrder }) {
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.qty, 0);

  return (
    <div style={{ maxWidth: 640, margin: "0 auto", padding: "32px 24px", fontFamily: "'Inter', sans-serif" }}>
      <button
        onClick={onBack}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 6,
          border: "none",
          background: "none",
          color: COLORS.inkSoft,
          fontSize: 13,
          cursor: "pointer",
          marginBottom: 16,
          padding: 0,
        }}
      >
        <ArrowLeft size={15} /> Back to products
      </button>

      <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 600, margin: "0 0 18px" }}>
        Your cart
      </h1>

      {items.length === 0 ? (
        <div style={{ ...cardStyle, textAlign: "center", color: COLORS.inkSoft, fontSize: 13.5 }}>
          Your cart is empty. Add a few products to get started.
        </div>
      ) : (
        <>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {items.map(({ product, qty }) => (
              <div
                key={product.id}
                style={{
                  ...cardStyle,
                  padding: 14,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{product.name}</div>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: COLORS.teal }}>
                    ${product.price}
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <button
                    onClick={() => onUpdateQty(product.id, Math.max(1, qty - 1))}
                    style={iconButtonStyle}
                    aria-label="Decrease quantity"
                  >
                    <Minus size={14} />
                  </button>
                  <span style={{ fontSize: 13.5, minWidth: 18, textAlign: "center" }}>{qty}</span>
                  <button
                    onClick={() => onUpdateQty(product.id, qty + 1)}
                    style={iconButtonStyle}
                    aria-label="Increase quantity"
                  >
                    <Plus size={14} />
                  </button>
                  <button
                    onClick={() => onRemove(product.id)}
                    style={{ ...iconButtonStyle, color: COLORS.rose }}
                    aria-label="Remove item"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div
            style={{
              ...cardStyle,
              marginTop: 16,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div>
              <div style={{ fontSize: 12, color: COLORS.inkSoft }}>Subtotal</div>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 19, fontWeight: 600 }}>
                ${subtotal.toFixed(2)}
              </div>
            </div>
            <button onClick={onPlaceOrder} style={{ ...primaryButtonStyle, width: "auto", padding: "10px 20px" }}>
              Place order
            </button>
          </div>
        </>
      )}
    </div>
  );
}

const iconButtonStyle = {
  border: `1px solid ${COLORS.border}`,
  background: "#fff",
  borderRadius: 6,
  width: 26,
  height: 26,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
  color: COLORS.ink,
};
